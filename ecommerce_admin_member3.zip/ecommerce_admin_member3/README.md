# E-Commerce (Member 3 - Admin Module) - Beginner Friendly Starter

This project is a simple monorepo with:
- server/ (Node.js + Express + MongoDB + JWT)
- client/ (React + Vite + Axios + React Router)

It focuses on the **Admin Module**:
- Admin login
- Admin dashboard
- Manage Products (CRUD)
- Manage Categories (CRUD)
- Manage Users (List + Block/Unblock)

> Note: This is intentionally kept simple so it looks like a beginner project.

---

## 1) Requirements
- Node.js 18+ recommended
- MongoDB (local or MongoDB Atlas)

---

## 2) Setup (Backend)
1. Open a terminal in the `server/` folder
2. Copy env file:
   - Windows: `copy .env.example .env`
   - macOS/Linux: `cp .env.example .env`
3. Update `.env` (Mongo URI + JWT secret)
4. Install and run:
   ```bash
   npm install
   npm run seed
   npm run dev
   ```

Backend will run at: http://localhost:5000

Seed creates:
- Admin user: **admin@example.com**
- Password: **admin123**

---

## 3) Setup (Frontend)
1. Open a second terminal in the `client/` folder
2. Install and run:
   ```bash
   npm install
   npm run dev
   ```

Frontend will run at: http://localhost:5173

---

## 4) Admin Login
Go to:
- http://localhost:5173/login

Use:
- Email: admin@example.com
- Password: admin123

---

## 5) API Quick List (Admin Protected)
- POST   /api/auth/login
- GET    /api/admin/users
- PUT    /api/admin/users/:id/block
- PUT    /api/admin/users/:id/unblock

Products:
- GET    /api/admin/products
- POST   /api/admin/products
- PUT    /api/admin/products/:id
- DELETE /api/admin/products/:id

Categories:
- GET    /api/admin/categories
- POST   /api/admin/categories
- PUT    /api/admin/categories/:id
- DELETE /api/admin/categories/:id

---

## Troubleshooting
- If you see "Unauthorized", login again (token might be missing)
- If MongoDB isn't connected, confirm your MONGO_URI in server/.env
