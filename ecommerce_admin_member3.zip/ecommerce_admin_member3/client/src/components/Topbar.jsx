import { Link, useNavigate } from "react-router-dom";

export default function Topbar() {
  const navigate = useNavigate();
  const token = localStorage.getItem("token");
  const role = localStorage.getItem("role");

  function logout() {
    localStorage.removeItem("token");
    localStorage.removeItem("role");
    navigate("/login");
  }

  return (
    <div className="topbar">
      <div className="topbar-inner">
        <div style={{ display: "flex", gap: 12, alignItems: "center" }}>
          <Link to="/" style={{ fontWeight: "bold" }}>E-Commerce Admin</Link>
          {token && role === "admin" ? <span className="badge">admin</span> : null}
        </div>

        <div style={{ display: "flex", gap: 10, alignItems: "center" }}>
          {token ? (
            <button className="gray" onClick={logout}>Logout</button>
          ) : (
            <Link to="/login">Login</Link>
          )}
        </div>
      </div>
    </div>
  );
}
