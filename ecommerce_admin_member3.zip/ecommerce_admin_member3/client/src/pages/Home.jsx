import { Link } from "react-router-dom";

export default function Home() {
  return (
    <div className="container">
      <h2>Welcome</h2>
      <div className="card">
        <p>This is a simple Admin Dashboard (Member 3 module).</p>
        <p>
          Go to: <Link to="/admin" style={{ color: "#2563eb" }}>Admin Dashboard</Link>
        </p>
      </div>
    </div>
  );
}
