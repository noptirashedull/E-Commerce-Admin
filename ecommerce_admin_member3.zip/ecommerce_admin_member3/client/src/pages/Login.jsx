import { useState } from "react";
import { useNavigate } from "react-router-dom";
import api from "../api/axios";

export default function Login() {
  const navigate = useNavigate();
  const [email, setEmail] = useState("admin@example.com");
  const [password, setPassword] = useState("admin123");
  const [error, setError] = useState("");

  async function handleLogin(e) {
    e.preventDefault();
    setError("");

    try {
      const res = await api.post("/api/auth/login", { email, password });
      const token = res.data?.data?.token;
      const role = res.data?.data?.user?.role;

      localStorage.setItem("token", token);
      localStorage.setItem("role", role);

      navigate("/admin");
    } catch (err) {
      setError(err?.response?.data?.message || "Login failed");
    }
  }

  return (
    <div className="container" style={{ maxWidth: 420 }}>
      <h2>Admin Login</h2>
      <div className="card">
        <form onSubmit={handleLogin}>
          <div style={{ marginBottom: 10 }}>
            <label>Email</label>
            <input value={email} onChange={(e) => setEmail(e.target.value)} />
          </div>
          <div style={{ marginBottom: 10 }}>
            <label>Password</label>
            <input type="password" value={password} onChange={(e) => setPassword(e.target.value)} />
          </div>

          {error ? <p style={{ color: "crimson" }}>{error}</p> : null}

          <button className="primary" type="submit">Login</button>
        </form>

        <p style={{ marginTop: 12, fontSize: 13, color: "#555" }}>
          Default: admin@example.com / admin123
        </p>
      </div>
    </div>
  );
}
