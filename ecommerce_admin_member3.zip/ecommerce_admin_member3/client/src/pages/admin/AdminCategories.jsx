import { useEffect, useState } from "react";
import api from "../../api/axios";

export default function AdminCategories() {
  const [categories, setCategories] = useState([]);
  const [name, setName] = useState("");
  const [editingId, setEditingId] = useState("");
  const [msg, setMsg] = useState("");

  async function load() {
    const res = await api.get("/api/admin/categories");
    setCategories(res.data.data || []);
  }

  useEffect(() => {
    load();
  }, []);

  async function submit(e) {
    e.preventDefault();
    setMsg("");

    try {
      if (!name.trim()) {
        setMsg("Name is required");
        return;
      }

      if (editingId) {
        await api.put(`/api/admin/categories/${editingId}`, { name });
        setMsg("Updated!");
      } else {
        await api.post("/api/admin/categories", { name });
        setMsg("Created!");
      }

      setName("");
      setEditingId("");
      await load();
    } catch (err) {
      setMsg(err?.response?.data?.message || "Failed");
    }
  }

  function startEdit(cat) {
    setEditingId(cat._id);
    setName(cat.name);
  }

  async function remove(id) {
    if (!confirm("Delete this category?")) return;
    try {
      await api.delete(`/api/admin/categories/${id}`);
      await load();
    } catch (err) {
      alert(err?.response?.data?.message || "Delete failed");
    }
  }

  return (
    <div>
      <div className="card" style={{ marginBottom: 12 }}>
        <h3 style={{ marginTop: 0 }}>{editingId ? "Edit Category" : "Create Category"}</h3>

        <form onSubmit={submit}>
          <div style={{ marginBottom: 10 }}>
            <label>Name</label>
            <input value={name} onChange={(e) => setName(e.target.value)} />
          </div>

          {msg ? <p style={{ color: msg.includes("Failed") ? "crimson" : "green" }}>{msg}</p> : null}

          <div style={{ display: "flex", gap: 10 }}>
            <button className="primary" type="submit">{editingId ? "Update" : "Create"}</button>
            <button className="gray" type="button" onClick={() => { setName(""); setEditingId(""); }}>Clear</button>
          </div>
        </form>
      </div>

      <div className="card">
        <h3 style={{ marginTop: 0 }}>Categories</h3>

        <table>
          <thead>
            <tr>
              <th>Name</th>
              <th style={{ width: 180 }}>Actions</th>
            </tr>
          </thead>
          <tbody>
            {categories.map((c) => (
              <tr key={c._id}>
                <td>{c.name}</td>
                <td style={{ display: "flex", gap: 8 }}>
                  <button className="gray" onClick={() => startEdit(c)}>Edit</button>
                  <button className="danger" onClick={() => remove(c._id)}>Delete</button>
                </td>
              </tr>
            ))}
            {categories.length === 0 ? (
              <tr>
                <td colSpan="2">No categories</td>
              </tr>
            ) : null}
          </tbody>
        </table>
      </div>
    </div>
  );
}
