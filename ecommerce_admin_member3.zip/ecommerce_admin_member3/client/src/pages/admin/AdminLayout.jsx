import { NavLink, Outlet } from "react-router-dom";

export default function AdminLayout() {
  const linkStyle = ({ isActive }) => ({
    display: "block",
    padding: "10px 12px",
    borderRadius: 8,
    background: isActive ? "#e5e7eb" : "transparent",
    marginBottom: 6
  });

  return (
    <div className="container">
      <h2>Admin Dashboard</h2>

      <div className="row">
        <div className="card" style={{ width: 240 }}>
          <NavLink to="/admin/products" style={linkStyle}>Products</NavLink>
          <NavLink to="/admin/categories" style={linkStyle}>Categories</NavLink>
          <NavLink to="/admin/users" style={linkStyle}>Users</NavLink>
        </div>

        <div className="col">
          <Outlet />
        </div>
      </div>
    </div>
  );
}
