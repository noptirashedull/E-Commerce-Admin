import { useEffect, useState } from "react";
import api from "../../api/axios";

export default function AdminProducts() {
  const [products, setProducts] = useState([]);
  const [categories, setCategories] = useState([]);

  const [form, setForm] = useState({
    name: "",
    categoryId: "",
    price: "",
    stock: "",
    rating: "",
    topSelling: false,
    offer: "",
    imageUrl: ""
  });

  const [editingId, setEditingId] = useState("");
  const [msg, setMsg] = useState("");

  async function load() {
    const catRes = await api.get("/api/admin/categories");
    setCategories(catRes.data.data || []);

    const prodRes = await api.get("/api/admin/products");
    setProducts(prodRes.data.data || []);
  }

  useEffect(() => {
    load();
  }, []);

  function onChange(e) {
    const { name, value, type, checked } = e.target;
    setForm((prev) => ({ ...prev, [name]: type === "checkbox" ? checked : value }));
  }

  function resetForm() {
    setForm({
      name: "",
      categoryId: "",
      price: "",
      stock: "",
      rating: "",
      topSelling: false,
      offer: "",
      imageUrl: ""
    });
    setEditingId("");
  }

  async function submit(e) {
    e.preventDefault();
    setMsg("");

    try {
      if (!form.categoryId) {
        setMsg("Please select a category");
        return;
      }

      if (editingId) {
        await api.put(`/api/admin/products/${editingId}`, form);
        setMsg("Updated!");
      } else {
        await api.post("/api/admin/products", form);
        setMsg("Created!");
      }

      await load();
      resetForm();
    } catch (err) {
      setMsg(err?.response?.data?.message || "Failed");
    }
  }

  function startEdit(p) {
    setEditingId(p._id);
    setForm({
      name: p.name || "",
      categoryId: p.categoryId?._id || p.categoryId || "",
      price: p.price ?? "",
      stock: p.stock ?? "",
      rating: p.rating ?? "",
      topSelling: !!p.topSelling,
      offer: p.offer || "",
      imageUrl: p.imageUrl || ""
    });
    window.scrollTo({ top: 0, behavior: "smooth" });
  }

  async function remove(id) {
    if (!confirm("Delete this product?")) return;
    await api.delete(`/api/admin/products/${id}`);
    await load();
  }

  return (
    <div>
      <div className="card" style={{ marginBottom: 12 }}>
        <h3 style={{ marginTop: 0 }}>{editingId ? "Edit Product" : "Create Product"}</h3>

        <form onSubmit={submit}>
          <div className="row">
            <div className="col">
              <label>Name</label>
              <input name="name" value={form.name} onChange={onChange} />
            </div>
            <div className="col">
              <label>Category</label>
              <select name="categoryId" value={form.categoryId} onChange={onChange}>
                <option value="">Select...</option>
                {categories.map((c) => (
                  <option key={c._id} value={c._id}>{c.name}</option>
                ))}
              </select>
            </div>
          </div>

          <div className="row" style={{ marginTop: 10 }}>
            <div className="col">
              <label>Price</label>
              <input name="price" value={form.price} onChange={onChange} />
            </div>
            <div className="col">
              <label>Stock</label>
              <input name="stock" value={form.stock} onChange={onChange} />
            </div>
            <div className="col">
              <label>Rating</label>
              <input name="rating" value={form.rating} onChange={onChange} />
            </div>
          </div>

          <div style={{ marginTop: 10 }}>
            <label>Offer</label>
            <input name="offer" value={form.offer} onChange={onChange} />
          </div>

          <div style={{ marginTop: 10 }}>
            <label>Image URL (optional)</label>
            <input name="imageUrl" value={form.imageUrl} onChange={onChange} />
          </div>

          <div style={{ marginTop: 10 }}>
            <label style={{ display: "flex", alignItems: "center", gap: 8 }}>
              <input type="checkbox" name="topSelling" checked={form.topSelling} onChange={onChange} />
              Top Selling
            </label>
          </div>

          {msg ? <p style={{ color: msg.includes("Failed") ? "crimson" : "green" }}>{msg}</p> : null}

          <div style={{ display: "flex", gap: 10 }}>
            <button className="primary" type="submit">{editingId ? "Update" : "Create"}</button>
            <button className="gray" type="button" onClick={resetForm}>Clear</button>
          </div>
        </form>
      </div>

      <div className="card">
        <h3 style={{ marginTop: 0 }}>Products</h3>
        <table>
          <thead>
            <tr>
              <th>Name</th>
              <th>Category</th>
              <th>Price</th>
              <th>Stock</th>
              <th>Top</th>
              <th>Actions</th>
            </tr>
          </thead>
          <tbody>
            {products.map((p) => (
              <tr key={p._id}>
                <td>{p.name}</td>
                <td>{p.categoryId?.name || "-"}</td>
                <td>{p.price}</td>
                <td>{p.stock}</td>
                <td>{p.topSelling ? "Yes" : "No"}</td>
                <td style={{ display: "flex", gap: 8 }}>
                  <button className="gray" onClick={() => startEdit(p)}>Edit</button>
                  <button className="danger" onClick={() => remove(p._id)}>Delete</button>
                </td>
              </tr>
            ))}
            {products.length === 0 ? (
              <tr>
                <td colSpan="6">No products</td>
              </tr>
            ) : null}
          </tbody>
        </table>
      </div>
    </div>
  );
}
