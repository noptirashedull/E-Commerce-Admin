import { useEffect, useState } from "react";
import api from "../../api/axios";

export default function AdminUsers() {
  const [users, setUsers] = useState([]);
  const [msg, setMsg] = useState("");

  async function load() {
    const res = await api.get("/api/admin/users");
    setUsers(res.data.data || []);
  }

  useEffect(() => {
    load();
  }, []);

  async function blockUser(id) {
    setMsg("");
    await api.put(`/api/admin/users/${id}/block`);
    setMsg("User blocked");
    await load();
  }

  async function unblockUser(id) {
    setMsg("");
    await api.put(`/api/admin/users/${id}/unblock`);
    setMsg("User unblocked");
    await load();
  }

  return (
    <div className="card">
      <h3 style={{ marginTop: 0 }}>Users</h3>
      {msg ? <p style={{ color: "green" }}>{msg}</p> : null}

      <table>
        <thead>
          <tr>
            <th>Name</th>
            <th>Email</th>
            <th>Role</th>
            <th>Blocked</th>
            <th style={{ width: 220 }}>Actions</th>
          </tr>
        </thead>
        <tbody>
          {users.map((u) => (
            <tr key={u._id}>
              <td>{u.name}</td>
              <td>{u.email}</td>
              <td>{u.role}</td>
              <td>{u.isBlocked ? "Yes" : "No"}</td>
              <td style={{ display: "flex", gap: 8 }}>
                {u.isBlocked ? (
                  <button className="primary" onClick={() => unblockUser(u._id)}>Unblock</button>
                ) : (
                  <button className="danger" onClick={() => blockUser(u._id)}>Block</button>
                )}
              </td>
            </tr>
          ))}
          {users.length === 0 ? (
            <tr>
              <td colSpan="5">No users</td>
            </tr>
          ) : null}
        </tbody>
      </table>

      <p style={{ fontSize: 13, color: "#555", marginTop: 12 }}>
        Tip: In this demo, seed creates only one admin user.  
        When Member 2 adds customer registration, you will see customers here.
      </p>
    </div>
  );
}
