import dotenv from "dotenv";
import bcrypt from "bcryptjs";
import mongoose from "mongoose";
import { connectDB } from "./src/config/db.js";
import { User } from "./src/models/User.js";
import { Category } from "./src/models/Category.js";
import { Product } from "./src/models/Product.js";

dotenv.config();

async function seed() {
  await connectDB(process.env.MONGO_URI);

  console.log(" Clearing old data...");
  await User.deleteMany({});
  await Category.deleteMany({});
  await Product.deleteMany({});

  console.log(" Creating admin user...");
  const passwordHash = await bcrypt.hash("admin123", 10);
  const admin = await User.create({
    name: "Admin",
    email: "admin@example.com",
    passwordHash,
    role: "admin",
    isBlocked: false
  });

  console.log(" Creating categories...");
  const mobiles = await Category.create({ name: "Mobiles" });
  const laptops = await Category.create({ name: "Laptops" });
  const accessories = await Category.create({ name: "Accessories" });

  console.log(" Creating products...");
  await Product.create([
    {
      name: "iPhone 15",
      categoryId: mobiles._id,
      price: 79999,
      stock: 10,
      rating: 4.5,
      topSelling: true,
      offer: "10% off",
      imageUrl: ""
    },
    {
      name: "Gaming Laptop",
      categoryId: laptops._id,
      price: 120000,
      stock: 5,
      rating: 4.2,
      topSelling: false,
      offer: "5% off",
      imageUrl: ""
    },
    {
      name: "Wireless Earbuds",
      categoryId: accessories._id,
      price: 3500,
      stock: 30,
      rating: 4.0,
      topSelling: true,
      offer: "",
      imageUrl: ""
    }
  ]);

  console.log(" Seed complete!");
  console.log("Admin login: admin@example.com / admin123");

  await mongoose.disconnect();
}

seed().catch((err) => {
  console.error(err);
  process.exit(1);
});
