import { fail } from "../utils/response.js";

export function requireAdmin(req, res, next) {
  if (!req.user) return fail(res, 401, "Unauthorized.");
  if (req.user.role !== "admin") return fail(res, 403, "Admin access only.");
  next();
}
