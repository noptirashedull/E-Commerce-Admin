import jwt from "jsonwebtoken";
import { fail } from "../utils/response.js";
import { User } from "../models/User.js";

export async function requireAuth(req, res, next) {
  try {
    const header = req.headers.authorization || "";
    const token = header.startsWith("Bearer ") ? header.slice(7) : null;

    if (!token) return fail(res, 401, "No token. Please login.");

    const decoded = jwt.verify(token, process.env.JWT_SECRET);
    const user = await User.findById(decoded.id).select("-passwordHash");

    if (!user) return fail(res, 401, "User not found.");
    if (user.isBlocked) return fail(res, 403, "Your account is blocked.");

    req.user = user;
    next();
  } catch (err) {
    return fail(res, 401, "Invalid token.");
  }
}
