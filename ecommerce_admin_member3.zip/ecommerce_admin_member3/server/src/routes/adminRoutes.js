import express from "express";
import { requireAuth } from "../middlewares/auth.js";
import { requireAdmin } from "../middlewares/admin.js";
import { ok, fail } from "../utils/response.js";
import { User } from "../models/User.js";
import { Product } from "../models/Product.js";
import { Category } from "../models/Category.js";

const router = express.Router();

// Admin-only guard for everything in this file
router.use(requireAuth, requireAdmin);

/* ---------------- USERS ---------------- */
router.get("/users", async (req, res) => {
  try {
    const users = await User.find().select("-passwordHash").sort({ createdAt: -1 });
    return ok(res, users, "Users list");
  } catch (err) {
    return fail(res, 500, err.message);
  }
});

router.put("/users/:id/block", async (req, res) => {
  try {
    const user = await User.findByIdAndUpdate(req.params.id, { isBlocked: true }, { new: true }).select("-passwordHash");
    if (!user) return fail(res, 404, "User not found.");
    return ok(res, user, "User blocked");
  } catch (err) {
    return fail(res, 500, err.message);
  }
});

router.put("/users/:id/unblock", async (req, res) => {
  try {
    const user = await User.findByIdAndUpdate(req.params.id, { isBlocked: false }, { new: true }).select("-passwordHash");
    if (!user) return fail(res, 404, "User not found.");
    return ok(res, user, "User unblocked");
  } catch (err) {
    return fail(res, 500, err.message);
  }
});

/*  CATEGORIES  */
router.get("/categories", async (req, res) => {
  try {
    const categories = await Category.find().sort({ name: 1 });
    return ok(res, categories, "Categories list");
  } catch (err) {
    return fail(res, 500, err.message);
  }
});

router.post("/categories", async (req, res) => {
  try {
    const { name } = req.body;
    if (!name) return fail(res, 400, "Category name is required.");

    const existing = await Category.findOne({ name: name.trim() });
    if (existing) return fail(res, 400, "Category already exists.");

    const category = await Category.create({ name: name.trim() });
    return ok(res, category, "Category created");
  } catch (err) {
    return fail(res, 500, err.message);
  }
});

router.put("/categories/:id", async (req, res) => {
  try {
    const { name } = req.body;
    if (!name) return fail(res, 400, "Category name is required.");

    const category = await Category.findByIdAndUpdate(
      req.params.id,
      { name: name.trim() },
      { new: true }
    );
    if (!category) return fail(res, 404, "Category not found.");

    return ok(res, category, "Category updated");
  } catch (err) {
    return fail(res, 500, err.message);
  }
});

router.delete("/categories/:id", async (req, res) => {
  try {
    // Beginner-friendly: block delete if products exist
    const count = await Product.countDocuments({ categoryId: req.params.id });
    if (count > 0) return fail(res, 400, "Can't delete. Products exist in this category.");

    const category = await Category.findByIdAndDelete(req.params.id);
    if (!category) return fail(res, 404, "Category not found.");

    return ok(res, null, "Category deleted");
  } catch (err) {
    return fail(res, 500, err.message);
  }
});

/*  PRODUCTS  */
router.get("/products", async (req, res) => {
  try {
    const products = await Product.find()
      .populate("categoryId", "name")
      .sort({ createdAt: -1 });
    return ok(res, products, "Products list");
  } catch (err) {
    return fail(res, 500, err.message);
  }
});

router.post("/products", async (req, res) => {
  try {
    const { name, categoryId, price, stock, rating, topSelling, offer, imageUrl } = req.body;

    if (!name || !categoryId || price === undefined) {
      return fail(res, 400, "name, categoryId and price are required.");
    }

    const category = await Category.findById(categoryId);
    if (!category) return fail(res, 400, "Invalid categoryId.");

    const product = await Product.create({
      name: name.trim(),
      categoryId,
      price: Number(price),
      stock: Number(stock || 0),
      rating: Number(rating || 0),
      topSelling: Boolean(topSelling),
      offer: offer || "",
      imageUrl: imageUrl || ""
    });

    return ok(res, product, "Product created");
  } catch (err) {
    return fail(res, 500, err.message);
  }
});

router.put("/products/:id", async (req, res) => {
  try {
    const { name, categoryId, price, stock, rating, topSelling, offer, imageUrl } = req.body;

    const update = {};
    if (name !== undefined) update.name = name.trim();
    if (categoryId !== undefined) update.categoryId = categoryId;
    if (price !== undefined) update.price = Number(price);
    if (stock !== undefined) update.stock = Number(stock);
    if (rating !== undefined) update.rating = Number(rating);
    if (topSelling !== undefined) update.topSelling = Boolean(topSelling);
    if (offer !== undefined) update.offer = offer;
    if (imageUrl !== undefined) update.imageUrl = imageUrl;

    const product = await Product.findByIdAndUpdate(req.params.id, update, { new: true });
    if (!product) return fail(res, 404, "Product not found.");

    return ok(res, product, "Product updated");
  } catch (err) {
    return fail(res, 500, err.message);
  }
});

router.delete("/products/:id", async (req, res) => {
  try {
    const product = await Product.findByIdAndDelete(req.params.id);
    if (!product) return fail(res, 404, "Product not found.");
    return ok(res, null, "Product deleted");
  } catch (err) {
    return fail(res, 500, err.message);
  }
});

export default router;
