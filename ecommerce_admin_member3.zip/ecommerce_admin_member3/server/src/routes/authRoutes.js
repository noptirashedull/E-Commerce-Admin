import express from "express";
import bcrypt from "bcryptjs";
import jwt from "jsonwebtoken";
import { User } from "../models/User.js";
import { ok, fail } from "../utils/response.js";

const router = express.Router();
// Simple register for demo
router.post("/register", async (req, res) => {
  try {
    const { name, email, password, role } = req.body;

    if (!name || !email || !password) {
      return fail(res, 400, "Name, email and password are required.");
    }

    const normalizedEmail = email.toLowerCase();

    const exists = await User.findOne({ email: normalizedEmail });
    if (exists) return fail(res, 400, "User already exists.");

    const passwordHash = await bcrypt.hash(password, 10);

    const user = await User.create({
      name,
      email: normalizedEmail,
      passwordHash,
      role: role || "customer", // default role
    });

    return ok(
      res,
      { user: { id: user._id, name: user.name, email: user.email, role: user.role } },
      "Registration successful"
    );
  } catch (err) {
    return fail(res, 500, err.message);
  }
});


// Very simple login for this demo (admin created by seed).
router.post("/login", async (req, res) => {
  try {
    const { email, password } = req.body;

    if (!email || !password) return fail(res, 400, "Email and password are required.");

    const user = await User.findOne({ email: email.toLowerCase() });
    if (!user) return fail(res, 401, "Invalid credentials.");

    if (user.isBlocked) return fail(res, 403, "Your account is blocked.");

    const match = await bcrypt.compare(password, user.passwordHash);
    if (!match) return fail(res, 401, "Invalid credentials.");

    const token = jwt.sign({ id: user._id, role: user.role }, process.env.JWT_SECRET, { expiresIn: "7d" });

    return ok(
      res,
      { user: { id: user._id, name: user.name, email: user.email, role: user.role }, token },
      "Login successful"
    );
  } catch (err) {
    return fail(res, 500, err.message);
  }
});

export default router;
