export function ok(res, data = null, message = "OK") {
  return res.json({ success: true, message, data });
}

export function fail(res, status = 400, message = "Something went wrong", extra = null) {
  return res.status(status).json({ success: false, message, extra });
}
